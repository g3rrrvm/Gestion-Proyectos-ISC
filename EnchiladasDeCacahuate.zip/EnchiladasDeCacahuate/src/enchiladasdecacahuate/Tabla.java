/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package enchiladasdecacahuate;

/**
 *
 * @author Gerson Morales
 */
public class Tabla {
    public void cortar(String ingrediente) {
        System.out.println("Cortando " + ingrediente + " en la tabla.");
    }
    
    public void lavar() {
        System.out.println("Lavando la tabla de cortar.");
    }
}
