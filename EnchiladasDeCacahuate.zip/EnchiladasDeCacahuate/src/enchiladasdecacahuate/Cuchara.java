/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package enchiladasdecacahuate;

/**
 *
 * @author Gerson Morales
 */
public class Cuchara {
    public void medir(String ingrediente) {
        System.out.println("Midiendo " + ingrediente + " con la cuchara.");
    }

    public void revolver(String ingrediente) {
        System.out.println("Revolviendo " + ingrediente + " con la cuchara.");
    }
}

