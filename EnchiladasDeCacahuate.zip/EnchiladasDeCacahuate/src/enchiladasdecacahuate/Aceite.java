/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package enchiladasdecacahuate;

/**
 *
 * @author Gerson Morales
 */
public class Aceite {
   private String tipo;
   
    public Aceite(String tipo) { 
        this.tipo = tipo; }
    
   @Override
    public boolean equals(Object o) { 
        return o instanceof Aceite && ((Aceite) o).tipo.equals(this.tipo); }
    
   @Override
    public String toString() {
        return "Aceite tipo: " + tipo; }
}
