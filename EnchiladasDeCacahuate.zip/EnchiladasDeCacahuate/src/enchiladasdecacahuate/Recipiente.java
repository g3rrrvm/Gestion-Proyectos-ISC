/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package enchiladasdecacahuate;

/**
 *
 * @author Gerson Morales
 */
public class Recipiente {
    public void agregar(String ingrediente) {
        System.out.println("Agregando " + ingrediente + " al recipiente.");
    }

    public void mezclar() {
        System.out.println("Mezclando los ingredientes en el recipiente.");
    }

    public void vaciar() {
        System.out.println("Vaciando el recipiente.");
    }
}
